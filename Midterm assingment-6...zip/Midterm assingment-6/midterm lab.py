import RPi.GPIO as GPIO
import time

SDI1_PIN = 29
RCLK1_PIN = 12
SRCLK1_PIN = 31

SDI2_PIN = 37
RCLK2_PIN = 16
SRCLK2_PIN = 35

segment_code = [0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x07, 0x7f, 0x6f, 0x77, 0x7c, 0x39, 0x5e, 0x79, 0x71, 0x80]
alpha_code = [0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71, 0x6F, 0x76, 0x06, 0x0E, 0x00, 0x38, 0x00, 0x54, 0x5C, 0x73,
              0x67, 0x50, 0x6D, 0x78, 0x1C, 0x2A, 0x76, 0x6E, 0x00, 0x00]


def print_msg():
    print('Program is running...')
    print('Please press Ctrl+C to end the program...')


def setup():
    GPIO.setmode(GPIO.BOARD)
    GPIO.setup(SDI1_PIN, GPIO.OUT)
    GPIO.setup(RCLK1_PIN, GPIO.OUT)
    GPIO.setup(SRCLK1_PIN, GPIO.OUT)
    GPIO.setup(SDI2_PIN, GPIO.OUT)
    GPIO.setup(RCLK2_PIN, GPIO.OUT)
    GPIO.setup(SRCLK2_PIN, GPIO.OUT)

    GPIO.output(SDI1_PIN, GPIO.LOW)
    GPIO.output(RCLK1_PIN, GPIO.LOW)
    GPIO.output(SRCLK1_PIN, GPIO.LOW)
    GPIO.output(SDI2_PIN, GPIO.LOW)
    GPIO.output(RCLK2_PIN, GPIO.LOW)
    GPIO.output(SRCLK2_PIN, GPIO.LOW)


def hc595_shift(dat, sdi, rclk, srclk):
    for bit in range(0, 8):
        GPIO.output(sdi, 0x80 & (dat << bit))
        GPIO.output(srclk, GPIO.HIGH)
        time.sleep(0.001)
        GPIO.output(srclk, GPIO.LOW)
    GPIO.output(rclk, GPIO.HIGH)
    time.sleep(0.01)
    GPIO.output(rclk, GPIO.LOW)


def string(sentence_text):
    string_in_pair = [("", sentence_text[0])]

    for i in range(1, len(sentence_text)):
        pair = (sentence_text[i - 1], sentence_text[i])
        string_in_pair.append(pair)

    string_in_pair.append((sentence_text[-1], ""))
    string_in_pair.append(("", ""))
    return string_in_pair


def display(msg_to_display):
    text_pairs = string(msg_to_display)
    for pair in text_pairs:
        char1 = pair[0]
        char2 = pair[1]

        if char1.isalpha():
            char_index = ord(char1.upper()) - ord('A')
            if 0 <= char_index < len(alpha_code):
                hc595_shift(alpha_code[char_index], SDI1_PIN, RCLK1_PIN, SRCLK1_PIN)
        elif char1.isdigit():
            char_index = int(char1)
            if 0 <= char_index < len(segment_code):
                hc595_shift(segment_code[char_index], SDI1_PIN, RCLK1_PIN, SRCLK1_PIN)
        else:
            hc595_shift(0x00, SDI1_PIN, RCLK1_PIN, SRCLK1_PIN)

        if char2.isalpha():
            char_index = ord(char2.upper()) - ord('A')
            if 0 <= char_index < len(alpha_code):
                hc595_shift(alpha_code[char_index], SDI2_PIN, RCLK2_PIN, SRCLK2_PIN)
        elif char2.isdigit():
            char_index = int(char2)
            if 0 <= char_index < len(segment_code):
                hc595_shift(segment_code[char_index], SDI2_PIN, RCLK2_PIN, SRCLK2_PIN)
        else:
            hc595_shift(0x00, SDI2_PIN, RCLK2_PIN, SRCLK2_PIN)

        time.sleep(0.5)


def loop():
    while True:
        display('hi you did good job')
        time.sleep(0.5)


def destroy():
    GPIO.cleanup()


if __name__ == '__main__':
    print_msg()
    setup()
    try:
        loop()
    except KeyboardInterrupt:
        destroy()
